#!/usr/bin/python

direction_up = 1
direction_right = 2
direction_down = 3
direction_left = 4
direction = 1