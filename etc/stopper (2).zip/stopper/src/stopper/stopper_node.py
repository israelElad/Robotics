#!/usr/bin/python
#
# stopper_node.py
#
#  Created on: Nov 13, 2017
#      Author: Mika Barkan
#
import rospy, sys
from stopper import Stopper
if __name__ == "__main__":
    rospy.init_node("stopper_node", argv=sys.argv)
    forward_speed = 0.5
    if rospy.has_param('~forward_speed'):
        forward_speed = rospy.get_param('~forward_speed')
    my_stopper = Stopper(forward_speed)
    my_stopper.start_moving()
