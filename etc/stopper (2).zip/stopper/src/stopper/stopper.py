#!/usr/bin/python
#
# stopper.py
#
#  Created on: Nov 13, 2017
#      Author: Mika Barkan
#

import rospy
import math
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

class Stopper(object):

    def __init__(self, forward_speed):
        self.forward_speed = forward_speed
        self.min_scan_angle = -30/180*math.pi
        self.max_scan_angle = 30 / 180 * math.pi
        self.min_dist_from_obstacle = 0.5
        self.keep_moving = True
        self.command_pub = rospy.Publisher("/cmd_vel_mux/input/teleop", Twist, queue_size=10)
        self.laser_subscriber = rospy.Subscriber("scan",LaserScan, self.scan_callback, queue_size=1)

    def start_moving(self):
        rate = rospy.Rate(10)
        rospy.loginfo("Starting to move")
        while not rospy.is_shutdown() and self.keep_moving:
            self.move_forward()
            rate.sleep()


    def move_forward(self):
        move_msg = Twist()
        move_msg.linear.x = self.forward_speed
        self.command_pub.publish(move_msg)

    def scan_callback(self, scan_msg):
        for dist in scan_msg.ranges:
            if dist < self.min_dist_from_obstacle:
                self.keep_moving = False
                break

