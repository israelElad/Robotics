#! /usr/bin/env python
#
# send_goal.py
#
#  Created on: Dec 11, 2017
#      Author: Mika Barkan
#

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from tf.transformations import quaternion_from_euler
from geometry_msgs.msg import Quaternion
from math import pi

if __name__ == '__main__':

    rospy.init_node('send_goal')

    ac = actionlib.SimpleActionClient("move_base", MoveBaseAction)
    rospy.loginfo("Waiting for move_base action server...")

    # Wait 60 seconds for the action server to become available
    ac.wait_for_server(rospy.Duration(60))
    rospy.loginfo("Connected to move base server")

    # send a goal to move_base
    goal = MoveBaseGoal()
    # Use the map frame to define goal poses
    goal.target_pose.header.frame_id = 'map'
    # Set the time stamp to "now"
    goal.target_pose.header.stamp = rospy.Time.now()
    # Set x,y positions
    goal.target_pose.pose.position.x = rospy.get_param('goal_x')
    goal.target_pose.pose.position.y = rospy.get_param('goal_y')
    # Convert the Euler angle to quaternion
    theta_rad = rospy.get_param('goal_theta') * (pi/180)
    quat = quaternion_from_euler(0, 0, theta_rad)
    q_msg = Quaternion(*quat)
    goal.target_pose.pose.orientation = q_msg

    # Sending the goal and waiting for the action to return
    rospy.loginfo("Sending robot to: x = %f, y = %f, theta = %f" % (goal.target_pose.pose.position.x, goal.target_pose.pose.position.y,rospy.get_param('goal_theta')))

    ac.send_goal(goal)
    ac.wait_for_result()

    # Check for result status
    if ac.get_state() == actionlib.GoalStatus.SUCCEEDED:
        rospy.loginfo("You have reached the goal!")
    else:
        rospy.loginfo("The base failed for some reason")


    # alternative code
    # if ac.send_goal_and_wait(goal) == actionlib.GoalStatus.SUCCEEDED:
    #     rospy.loginfo("You have reached the goal!")
    # else:
    #     rospy.loginfo("The base failed for some reason")









