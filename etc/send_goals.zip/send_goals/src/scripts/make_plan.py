#! /usr/bin/env python
#
# make_plan.py
#
#  Created on: Dec 11, 2017
#      Author: Mika Barkan
#

import rospy
from geometry_msgs.msg import PoseStamped
from nav_msgs.srv import GetPlan, GetMapResponse
from nav_msgs.msg import Path

goal_tolerance = 0.1

def get_request():
    start = PoseStamped()
    start.header.frame_id = "map"
    start.pose.position.x = 0
    start.pose.position.y = 0
    start.pose.orientation.w = 1.0
    goal = PoseStamped()
    goal.header.frame_id = "map"
    goal.pose.position.x = 2.0
    goal.pose.position.y = -2.0
    goal.pose.orientation.w = 1.0
    global goal_tolerance
    return (start, goal, goal_tolerance)


if __name__ == '__main__':

    rospy.init_node("make_plan")
    rospy.loginfo("Waiting for service move_base/make_plan to become available")
    rospy.wait_for_service('move_base/make_plan')
    try:
        get_plan = rospy.ServiceProxy('move_base/make_plan', GetPlan)
        resp = get_plan(*get_request())
    except rospy.ServiceException, e:
        rospy.logerr("Service call failed: %s" % e)
        exit(-1)

    if len(resp.plan.poses) > 0:
        for p in resp.plan.poses:
            rospy.loginfo("x = %f, y = %f" % (p.pose.position.x, p.pose.position.y))
    else:
        rospy.logwarn("Got empty plan")








