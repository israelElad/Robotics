#!/usr/bin/env python
import rospy
import tf

if __name__ == '__main__':
    rospy.init_node('robot_location')
    listener = tf.TransformListener()
    rate = rospy.Rate(2.0)
    listener.waitForTransform("/map", "/base_footprint", rospy.Time(0), rospy.Duration(10.0))
    while not rospy.is_shutdown():
        try:
            (trans,rot) = listener.lookupTransform("/map", "/base_footprint", rospy.Time(0))
            robot_x = trans[0]
            robot_y = trans[1]
            rospy.loginfo("current position (%f,%f)" % (robot_x, robot_y))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException), e:
            rospy.logerr("Service call failed: %s" % e)

        rate.sleep()